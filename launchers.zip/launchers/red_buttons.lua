require 'cairo'

function conky_draw_buttons()

    if conky_window == nil then return end

    local cs = cairo_xlib_surface_create(
        conky_window.display,
        conky_window.drawable,
        conky_window.visual,
        conky_window.width,
        conky_window.height
    )

    local cr = cairo_create(cs)

    local button_size = 50
    local radius = button_size / 2
    local y = 15

    -- X positions for 4 buttons
    local x_positions = {
        30,
        106,
        184,
        262
    }

    for i = 1, 4 do
        local center_x = x_positions[i] + radius
        local center_y = y + radius

        cairo_set_source_rgba(cr, 1, 0, 0, 1) -- solid red
        cairo_arc(cr, center_x, center_y, radius, 0, 2 * math.pi)
        cairo_fill(cr)
    end

    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end
