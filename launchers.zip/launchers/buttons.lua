-- ~/.conky/Tahoe/circle_buttons/buttons.lua
local button_size = 50
local radius = button_size / 2
local y = 15

local x_positions = {
    30,
    106,
    184,
    262
}

-- ===============================
-- DRAW BUTTONS
-- ===============================
require 'cairo'
function conky_draw_buttons()
    if conky_window == nil then return end

    local cs = cairo_xlib_surface_create(
        conky_window.display,
        conky_window.drawable,
        conky_window.visual,
        conky_window.width,
        conky_window.height
    )

    local cr = cairo_create(cs)

    for i = 1, 4 do
        local center_x = x_positions[i] + radius
        local center_y = y + radius

        cairo_set_source_rgba(cr, 1, 0, 0, 1) -- red fill
        cairo_arc(cr, center_x, center_y, radius, 0, 2 * math.pi)
        cairo_fill(cr)
    end

    cairo_destroy(cr)
    cairo_surface_destroy(cs)
end

-- ===============================
-- MOUSE HANDLER (new 1.19.8 table syntax)
-- ===============================
function conky_mouse_handler(event)
    if event.type ~= "button_down" then return end

    local mx, my = event.x, event.y

    for i = 1, 4 do
        local center_x = x_positions[i] + radius
        local center_y = y + radius

        -- Circle hit test
        local dx = mx - center_x
        local dy = my - center_y
        local distance = math.sqrt(dx*dx + dy*dy)

        if distance <= radius then
            -- Debug notification
            os.execute("notify-send 'Conky Button' 'Button " .. i .. " clicked' &")
            os.execute("paplay ~/.conky/Tahoe/cercle/notification.oga &")

            if i == 1 then
                os.execute("xdg-open https://google.com &")
            elseif i == 2 then
                os.execute("xdg-open https://www.reddit.com/r/Conkyporn &")
            elseif i == 3 then
                os.execute("xdg-open https://forums.linuxmint.com &")
            elseif i == 4 then
                os.execute("gnome-calculator &")
            end

            return
        end
    end
end
