#!/bin/sh

cd "$(dirname "$0")"

conky -c cercle &

exit